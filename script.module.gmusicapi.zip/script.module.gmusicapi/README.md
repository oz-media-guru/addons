xbmc-gmusicapi
==============

gmusicapi packed for xbmc
