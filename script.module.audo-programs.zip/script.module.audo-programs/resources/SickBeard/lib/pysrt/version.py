VERSION = (1, 0, 1)
VERSION_STRING = '.'.join(str(i) for i in VERSION)
