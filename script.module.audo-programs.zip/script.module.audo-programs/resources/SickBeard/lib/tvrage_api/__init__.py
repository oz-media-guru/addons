
__version__ = '1.0'
__author__ = 'echel0n'
__license__ = 'BSD'
