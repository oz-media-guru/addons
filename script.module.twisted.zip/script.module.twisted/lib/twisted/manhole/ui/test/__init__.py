# Copyright (c) 2009 Twisted Matrix Laboratories.
"""
Tests for the L{twisted.manhole.ui} package.
"""
