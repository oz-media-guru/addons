import urllib2, urllib, sys, os, re, hashlib
from BeautifulSoup import BeautifulSoup, Tag, NavigableString
import xbmc,xbmcplugin,xbmcgui,xbmcaddon
from t0mm0.common.addon import Addon
from t0mm0.common.net import Net
net = Net()
try: 
	import simplejson as json
except ImportError: 
	import json 

ADDON_ID = 'script.module.donnie'

class IMDB():
	def __init__(self, REG):
		if REG:
			self.REG = REG
		self.base_url = 'http://m.imdb.com/'
		self.addon = xbmcaddon.Addon(id=ADDON_ID)
		self.username = self.getSetting('imdb-username')
		self.password = self.getSetting('imdb-password')
		
	def getSetting(self, setting):
		return self.REG.getSetting(setting)		
		
	def authenticate(self):
		auth_url = 'https://secure.imdb.com/oauth/m_login'
		post_dict = {
			'login' : self.username,
			'password' : self.password,
			"submit" : "Sign In"
		}	
		response = net.http_POST(auth_url, post_dict).content
		if re.search('>Sign Out<', response):
			return True
		else:
			return False
		
	def getJSON(self, uri):
		url = self.base_url + uri
		response = net.http_GET(url).content
		return json.loads(response)

	def getTop250(self):
		return self.getJSON('chart/top_json')

	def getPopular(self):
		return self.getJSON('chart/tv_json')

	def getMovieMeter(self):
		return self.getJSON('chart/moviemeter_json')
	
	def getBestPictures(self):
		return self.getJSON('feature/bestpicture_json')

	def getWatchList(self):
		if self.authenticate():
			return self.getJSON('list/userlist_json?list_class=watchlist&limit=1000')
	
	
