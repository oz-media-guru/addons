UPDATE rw_providers SET priority=providerid;
