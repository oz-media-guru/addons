ALTER TABLE `rw_providers` ADD COLUMN `priority` INT(11) NULL DEFAULT 100  AFTER `enabled` ;

